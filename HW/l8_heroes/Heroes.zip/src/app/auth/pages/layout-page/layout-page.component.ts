import { Component } from '@angular/core';

@Component({
  selector: 'app-layout-page',
  standalone: true,
  imports: [],
  templateUrl: './layout-page.component.html',
  styles: ``
})
export class LayoutPageComponent {

}
