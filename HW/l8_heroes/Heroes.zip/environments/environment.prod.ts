export const environments = {
    baseUrl : 'https://servidor_de_mi_cliente/api'
}